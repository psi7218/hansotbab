-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: j10b209.p.ssafy.io    Database: hansotbab
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fcm_token`
--

DROP TABLE IF EXISTS `fcm_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fcm_token` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fcm_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fcm_token`
--

LOCK TABLES `fcm_token` WRITE;
/*!40000 ALTER TABLE `fcm_token` DISABLE KEYS */;
INSERT INTO `fcm_token` VALUES ('bjo8244@naver.com','fBSTeovURf6zg3QQqvi-ZP:APA91bFSevVfZaV1nqZcoLsbBSuSpAdW0gVHWdAW8NlSbPT1_aXJ2Anxgm78wgu119usk_hRb5DShadHMsJt2DeVO51hXqFf8OLDMPS0Kz17rkweHydFOjJ_nxeuNYqLJPRTaNHCtowc'),('exhilar@gmail.com','fOtN9_eqT-W6XytEFudTZT:APA91bHk6ol0gD4jcGgAbkezwPrIW10NEGRXhFcrZvqYlvttZOWgh-q_aoqi0Ul-qE1BonKW78R10CYswAZqkZPKFRgAmeXvF5J-zhIdITQNWCDBvkER6sy63ahZeDdLgMCBvUOe36c9'),('lisa1072@naver.com','eW8zPri3TWCkCgR6u_gjMx:APA91bGvP65H12VWakN9uyqXgmQNSN_OwId8K-K_kZ-NTIpM_-0ZRX9SIRETcIcneEQJVXZ58mCXclptRnfJ-TdpjdwIfc_LXE0mnYwAr07jov0PKgvOb5c8x59hADNZ0bnCwEDJzXfr'),('psi7218@naver.com','eYyklF0MTr6P0rZb-ja5Fe:APA91bH1Mmm8kqlY7zkNkSBtgT67g3oXoYx5VrksuBWNtbchMdpoJfEUtzHsLPKKe2fFn5dF-osAUF1aWY3y00DzSa1gK-gaNr4pswc0GLSvsG-F1oBmETfhyEtbxJjydkEoDjrRmm52');
/*!40000 ALTER TABLE `fcm_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04  9:46:29
