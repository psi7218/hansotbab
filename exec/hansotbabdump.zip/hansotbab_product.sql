-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: j10b209.p.ssafy.io    Database: hansotbab
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `is_delete` tinyint(1) DEFAULT '0',
  `product_amount` int NOT NULL,
  `product_bring_count` int NOT NULL,
  `product_is_soldout` bit(1) NOT NULL,
  `product_soldout` bit(1) NOT NULL,
  `created_date` datetime(6) NOT NULL,
  `fridge_id` bigint NOT NULL,
  `modified_date` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL AUTO_INCREMENT,
  `user_uuid` binary(16) NOT NULL,
  `product_image_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_memo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_category` enum('채소','과일','음료','소스_조미료','유제품','축산_계란','간식류','가공식품','쌀_잡곡류','밥_반찬류','기타') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `FKeqwyl26xhcbu1l16u5gkg5hx0` (`fridge_id`),
  KEY `FKjghyk74mk900scaq7uhrd058a` (`user_uuid`),
  CONSTRAINT `FKeqwyl26xhcbu1l16u5gkg5hx0` FOREIGN KEY (`fridge_id`) REFERENCES `fridge` (`fridge_id`),
  CONSTRAINT `FKjghyk74mk900scaq7uhrd058a` FOREIGN KEY (`user_uuid`) REFERENCES `user` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (0,10,1,_binary '\0',_binary '\0','2024-04-03 10:35:12.357375',27,'2024-04-03 14:58:54.111436',7,_binary 'ZmH�o\�J��%�\�\��\�','117df8db-8be8-4eb6-9ec7-6ff7d754de421000016027.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/117df8db-8be8-4eb6-9ec7-6ff7d754de421000016027.jpg','좀 많이 달아요','립톤 버블티','가공식품'),(0,10,0,_binary '\0',_binary '\0','2024-04-03 10:35:21.057825',27,'2024-04-03 10:35:21.057825',8,_binary 'ZmH�o\�J��%�\�\��\�','010fcd0f-a004-4c49-b4c3-4fb1179e95fe1000016027.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/010fcd0f-a004-4c49-b4c3-4fb1179e95fe1000016027.jpg','좀 많이 달아요','립톤 버블티','가공식품'),(0,10,0,_binary '\0',_binary '\0','2024-04-03 10:35:21.489050',27,'2024-04-03 10:35:21.489050',9,_binary 'ZmH�o\�J��%�\�\��\�','5ba9c209-4d57-407c-a0cd-ef8e8e2e78071000016027.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/5ba9c209-4d57-407c-a0cd-ef8e8e2e78071000016027.jpg','좀 많이 달아요','립톤 버블티','가공식품'),(0,1,0,_binary '\0',_binary '\0','2024-04-03 11:29:14.035005',1,'2024-04-03 11:29:14.035005',10,_binary '�_0.��F\\�M�2b\Z{Z','a561d5f6-504a-4d94-8141-4b7e30dd1507c7cb6786-0d4b-452a-a8c2-edfd110e6c0a9086094559113722699.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/a561d5f6-504a-4d94-8141-4b7e30dd1507c7cb6786-0d4b-452a-a8c2-edfd110e6c0a9086094559113722699.jpg','맛있게 드세요.','펩시','음료'),(0,1,1,_binary '',_binary '\0','2024-04-03 11:41:12.548563',1,'2024-04-03 15:39:54.361321',11,_binary '�_0.��F\\�M�2b\Z{Z','b5101eb6-2061-4e71-afaf-f56ecb2d466779e464d0-f694-4465-bcb5-ad1307cce966610011176013936919.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/b5101eb6-2061-4e71-afaf-f56ecb2d466779e464d0-f694-4465-bcb5-ad1307cce966610011176013936919.jpg','스프라이트 입니다.','스프라이트','음료'),(0,1,1,_binary '',_binary '\0','2024-04-03 11:47:53.551757',1,'2024-04-03 15:38:33.227617',12,_binary '�_0.��F\\�M�2b\Z{Z','b3ae8c2e-c0b9-4a7f-a76a-8c5f158676985957a7d8-2df7-4c25-8fb2-eef781d85efc4671779211544679252.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/b3ae8c2e-c0b9-4a7f-a76a-8c5f158676985957a7d8-2df7-4c25-8fb2-eef781d85efc4671779211544679252.jpg','초코하임입니다.','쵸코하임','간식류'),(0,1,1,_binary '',_binary '\0','2024-04-03 11:56:04.290104',1,'2024-04-03 15:24:31.917840',13,_binary '�_0.��F\\�M�2b\Z{Z','af9574cf-c99d-429f-b14d-8ddfe77c5a18e71f3a76-4a42-40c5-9036-b58059ec04cc6004620322899955877.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/af9574cf-c99d-429f-b14d-8ddfe77c5a18e71f3a76-4a42-40c5-9036-b58059ec04cc6004620322899955877.jpg','다이제입니다','다이제 초코','가공식품'),(0,1,1,_binary '',_binary '\0','2024-04-03 12:12:00.728016',1,'2024-04-03 15:47:03.853464',14,_binary '�_0.��F\\�M�2b\Z{Z','437c56b6-ca02-418e-9e6e-8af0d28b79f53e17f18a-35d3-4e87-a580-0d1ca72158ac3200995554065027745.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/437c56b6-ca02-418e-9e6e-8af0d28b79f53e17f18a-35d3-4e87-a580-0d1ca72158ac3200995554065027745.jpg','썬칩입니다','썬칩 오리지날','간식류'),(0,1,1,_binary '',_binary '\0','2024-04-03 13:20:32.495542',1,'2024-04-03 15:55:10.496893',18,_binary '�_0.��F\\�M�2b\Z{Z','f7bfd4b8-3fd8-4028-904d-b484fe9d7c1f1f933314-c682-4ed2-9bc4-16a01bffc31a7675677981085767441.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/f7bfd4b8-3fd8-4028-904d-b484fe9d7c1f1f933314-c682-4ed2-9bc4-16a01bffc31a7675677981085767441.jpg','꽃게랑','꽃게랑','간식류'),(0,1,0,_binary '\0',_binary '\0','2024-04-03 14:05:53.037848',2,'2024-04-03 14:05:53.037848',21,_binary '�_0.��F\\�M�2b\Z{Z','2b1d2926-6086-4e9c-80f5-86d65fe8b1beKakaoTalk_20240402_205903980-grdqord6gi8adqqdyhdxx35t1y.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/2b1d2926-6086-4e9c-80f5-86d65fe8b1beKakaoTalk_20240402_205903980-grdqord6gi8adqqdyhdxx35t1y.jpg','콘칩\n','콘칩','간식류'),(0,1,0,_binary '\0',_binary '\0','2024-04-03 14:08:04.810209',2,'2024-04-03 14:08:04.810209',22,_binary '�_0.��F\\�M�2b\Z{Z','af643a7e-05e7-4977-96ff-20a4a2f6566dKakaoTalk_20240402_205903980-grdqord6gi8adqqdyhdxx35t1y.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/af643a7e-05e7-4977-96ff-20a4a2f6566dKakaoTalk_20240402_205903980-grdqord6gi8adqqdyhdxx35t1y.jpg','콘칩입니다\n','콘칩','간식류'),(0,10,0,_binary '\0',_binary '\0','2024-04-03 16:48:59.955407',16,'2024-04-03 16:48:59.955407',29,_binary '�_0.��F\\�M�2b\Z{Z','af82fd27-3b89-4cf7-8805-e6137f0ebb99KakaoTalk_20240402_205903980-grdqord6gi8adqqdyhdxx35t1y.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/af82fd27-3b89-4cf7-8805-e6137f0ebb99KakaoTalk_20240402_205903980-grdqord6gi8adqqdyhdxx35t1y.jpg','콘칩','콘칩','간식류'),(0,3,0,_binary '\0',_binary '\0','2024-04-04 00:45:53.410189',1,'2024-04-04 00:45:53.410189',30,_binary '*&s�\�0F(�u4�#G','e6d7a0ed-11d4-4a7d-a758-54d29f0d1e63KakaoTalk_20240402_205903980_02.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/e6d7a0ed-11d4-4a7d-a758-54d29f0d1e63KakaoTalk_20240402_205903980_02.jpg','콘칩가져가세요~~','크라운)콘칩(군옥수수)70G','간식류'),(0,3,0,_binary '\0',_binary '\0','2024-04-04 00:46:21.229539',1,'2024-04-04 00:46:21.229539',31,_binary '*&s�\�0F(�u4�#G','0b877b27-8220-4144-9bb0-2a46d93ea25fKakaoTalk_20240402_205903980_02.jpg','https://ssafyjoblog.s3.ap-northeast-2.amazonaws.com/0b877b27-8220-4144-9bb0-2a46d93ea25fKakaoTalk_20240402_205903980_02.jpg','콘칩가져가세요~~','크라운)콘칩(군옥수수)70G','간식류');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04  9:46:43
