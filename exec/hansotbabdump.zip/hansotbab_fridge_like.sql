-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: j10b209.p.ssafy.io    Database: hansotbab
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fridge_like`
--

DROP TABLE IF EXISTS `fridge_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fridge_like` (
  `created_date` datetime(6) NOT NULL,
  `fridge_id` bigint DEFAULT NULL,
  `fridge_likes_id` bigint NOT NULL AUTO_INCREMENT,
  `modified_date` datetime(6) NOT NULL,
  `user_uuid` binary(16) DEFAULT NULL,
  PRIMARY KEY (`fridge_likes_id`),
  KEY `FKo78qunro8ntshnksa98n2y7p4` (`fridge_id`),
  KEY `FK8hxccayj3a26b35no4gw5odve` (`user_uuid`),
  CONSTRAINT `FK8hxccayj3a26b35no4gw5odve` FOREIGN KEY (`user_uuid`) REFERENCES `user` (`uuid`),
  CONSTRAINT `FKo78qunro8ntshnksa98n2y7p4` FOREIGN KEY (`fridge_id`) REFERENCES `fridge` (`fridge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fridge_like`
--

LOCK TABLES `fridge_like` WRITE;
/*!40000 ALTER TABLE `fridge_like` DISABLE KEYS */;
INSERT INTO `fridge_like` VALUES ('2024-04-03 08:34:02.586801',1,2,'2024-04-03 08:34:02.586801',_binary '�_0.��F\\�M�2b\Z{Z'),('2024-04-04 00:24:48.758494',5,10,'2024-04-04 00:24:48.758494',_binary '�_0.��F\\�M�2b\Z{Z'),('2024-04-04 00:44:59.699108',1,11,'2024-04-04 00:44:59.699108',_binary '\'��\�B忓\�)j\�/');
/*!40000 ALTER TABLE `fridge_like` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04  9:46:37
